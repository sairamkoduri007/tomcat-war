# example-tomcat-war

This is an example java build and deploy of the resulting
war file to a tomcat 7 server.

editing it for end to end cicd

retrigger

auto-trigger demo with pipeline demo for November class
